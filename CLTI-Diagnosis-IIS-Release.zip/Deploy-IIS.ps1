# =============================================
# CLTI Diagnosis - IIS Deployment Script
# =============================================
# Цей скрипт автоматизує розгортання додатку на IIS
# Запускайте з правами адміністратора!
# =============================================

param(
    [Parameter(Mandatory=$false)]
    [string]$SiteName = "CLTI-Diagnosis",
    
    [Parameter(Mandatory=$false)]
    [string]$AppPoolName = "CLTI-Diagnosis-Pool",
    
    [Parameter(Mandatory=$false)]
    [string]$PhysicalPath = "C:\inetpub\wwwroot\CLTI-Diagnosis",
    
    [Parameter(Mandatory=$false)]
    [string]$HostName = "antsdemo02.demo.dragon-cloud.org",
    
    [Parameter(Mandatory=$false)]
    [int]$HttpsPort = 443,
    
    [Parameter(Mandatory=$false)]
    [int]$HttpPort = 80,
    
    [Parameter(Mandatory=$false)]
    [string]$CertificateThumbprint = ""
)

# Перевірка прав адміністратора
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$isAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    Write-Host "❌ ПОМИЛКА: Цей скрипт потрібно запускати з правами адміністратора!" -ForegroundColor Red
    Write-Host "Клікніть правою кнопкою на PowerShell і виберіть 'Run as Administrator'" -ForegroundColor Yellow
    exit 1
}

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  CLTI Diagnosis - IIS Deployment Script" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

# Імпорт модуля WebAdministration
Import-Module WebAdministration -ErrorAction SilentlyContinue
if (-not (Get-Module -Name WebAdministration)) {
    Write-Host "❌ ПОМИЛКА: Модуль WebAdministration не знайдено!" -ForegroundColor Red
    Write-Host "Переконайтеся, що IIS встановлено." -ForegroundColor Yellow
    exit 1
}

# Функція для виведення кроків
function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "▶ $Message" -ForegroundColor Green
}

# Функція для виведення попереджень
function Write-Warning-Custom {
    param([string]$Message)
    Write-Host "⚠ $Message" -ForegroundColor Yellow
}

# Функція для виведення помилок
function Write-Error-Custom {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

# Функція для виведення успіху
function Write-Success {
    param([string]$Message)
    Write-Host "✓ $Message" -ForegroundColor Green
}

# =============================================
# Крок 1: Перевірка .NET Runtime
# =============================================
Write-Step "Перевірка .NET 9.0 Runtime..."

$dotnetRuntimes = dotnet --list-runtimes 2>$null | Select-String "Microsoft.AspNetCore.App 9.0"
if ($dotnetRuntimes) {
    Write-Success ".NET 9.0 Runtime знайдено"
    $dotnetRuntimes | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }
} else {
    Write-Error-Custom ".NET 9.0 Runtime не знайдено!"
    Write-Host "Завантажте та встановіть ASP.NET Core 9.0 Runtime - Windows Hosting Bundle" -ForegroundColor Yellow
    Write-Host "https://dotnet.microsoft.com/download/dotnet/9.0" -ForegroundColor Cyan
    exit 1
}

# =============================================
# Крок 2: Перевірка файлів
# =============================================
Write-Step "Перевірка файлів додатку..."

$currentPath = Get-Location
$requiredFiles = @(
    "CLTI.Diagnosis.dll",
    "web.config",
    "appsettings.json",
    "wwwroot"
)

$missingFiles = @()
foreach ($file in $requiredFiles) {
    $filePath = Join-Path $currentPath $file
    if (-not (Test-Path $filePath)) {
        $missingFiles += $file
    }
}

if ($missingFiles.Count -gt 0) {
    Write-Error-Custom "Відсутні необхідні файли:"
    $missingFiles | ForEach-Object { Write-Host "  - $_" -ForegroundColor Red }
    Write-Host "Переконайтеся, що ви запускаєте скрипт з папки publish." -ForegroundColor Yellow
    exit 1
}

Write-Success "Всі необхідні файли знайдено"

# =============================================
# Крок 3: Створення папки для сайту
# =============================================
Write-Step "Створення папки для сайту: $PhysicalPath"

if (Test-Path $PhysicalPath) {
    Write-Warning-Custom "Папка вже існує. Файли будуть перезаписані."
    $response = Read-Host "Продовжити? (Y/N)"
    if ($response -ne "Y" -and $response -ne "y") {
        Write-Host "Розгортання скасовано." -ForegroundColor Yellow
        exit 0
    }
} else {
    New-Item -Path $PhysicalPath -ItemType Directory -Force | Out-Null
    Write-Success "Папку створено"
}

# =============================================
# Крок 4: Копіювання файлів
# =============================================
Write-Step "Копіювання файлів..."

try {
    Copy-Item -Path "$currentPath\*" -Destination $PhysicalPath -Recurse -Force
    Write-Success "Файли скопійовано"
} catch {
    Write-Error-Custom "Помилка при копіюванні файлів: $_"
    exit 1
}

# =============================================
# Крок 5: Створення папки для логів
# =============================================
Write-Step "Створення папки для логів..."

$logsPath = Join-Path $PhysicalPath "logs"
if (-not (Test-Path $logsPath)) {
    New-Item -Path $logsPath -ItemType Directory -Force | Out-Null
    Write-Success "Папку logs створено"
} else {
    Write-Success "Папка logs вже існує"
}

# =============================================
# Крок 6: Створення Application Pool
# =============================================
Write-Step "Створення Application Pool: $AppPoolName"

if (Test-Path "IIS:\AppPools\$AppPoolName") {
    Write-Warning-Custom "Application Pool вже існує"
    Stop-WebAppPool -Name $AppPoolName -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
} else {
    New-WebAppPool -Name $AppPoolName | Out-Null
    Write-Success "Application Pool створено"
}

# Налаштування Application Pool
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name "managedRuntimeVersion" -Value ""
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name "startMode" -Value "AlwaysRunning"
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name "processModel.idleTimeout" -Value "00:00:00"
Write-Success "Application Pool налаштовано"

# =============================================
# Крок 7: Створення веб-сайту
# =============================================
Write-Step "Створення веб-сайту: $SiteName"

if (Test-Path "IIS:\Sites\$SiteName") {
    Write-Warning-Custom "Веб-сайт вже існує. Видалення старого сайту..."
    Remove-Website -Name $SiteName
    Start-Sleep -Seconds 2
}

# Створення сайту з HTTP binding
New-Website -Name $SiteName `
    -PhysicalPath $PhysicalPath `
    -ApplicationPool $AppPoolName `
    -Port $HttpPort `
    -HostHeader $HostName `
    -Force | Out-Null

Write-Success "Веб-сайт створено"

# =============================================
# Крок 8: Додавання HTTPS binding
# =============================================
Write-Step "Налаштування HTTPS binding..."

if ($CertificateThumbprint -ne "") {
    try {
        New-WebBinding -Name $SiteName `
            -Protocol "https" `
            -Port $HttpsPort `
            -HostHeader $HostName `
            -SslFlags 1
        
        $binding = Get-WebBinding -Name $SiteName -Protocol "https"
        $binding.AddSslCertificate($CertificateThumbprint, "my")
        
        Write-Success "HTTPS binding додано з сертифікатом"
    } catch {
        Write-Warning-Custom "Не вдалося додати HTTPS binding: $_"
        Write-Host "Додайте HTTPS binding вручну в IIS Manager" -ForegroundColor Yellow
    }
} else {
    Write-Warning-Custom "Certificate Thumbprint не вказано"
    Write-Host "Додайте HTTPS binding вручну в IIS Manager" -ForegroundColor Yellow
    Write-Host "Або запустіть скрипт з параметром -CertificateThumbprint" -ForegroundColor Yellow
}

# =============================================
# Крок 9: Налаштування прав доступу
# =============================================
Write-Step "Налаштування прав доступу..."

$identity = "IIS AppPool\$AppPoolName"

# Права на основну папку
$acl = Get-Acl $PhysicalPath
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    $identity,
    "ReadAndExecute",
    "ContainerInherit,ObjectInherit",
    "None",
    "Allow"
)
$acl.SetAccessRule($accessRule)
Set-Acl $PhysicalPath $acl
Write-Success "Права на основну папку налаштовано"

# Права на папку logs
$acl = Get-Acl $logsPath
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
    $identity,
    "Modify",
    "ContainerInherit,ObjectInherit",
    "None",
    "Allow"
)
$acl.SetAccessRule($accessRule)
Set-Acl $logsPath $acl
Write-Success "Права на папку logs налаштовано"

# Права на папку Photo (якщо існує)
$photoPath = Join-Path $PhysicalPath "wwwroot\Photo"
if (Test-Path $photoPath) {
    $acl = Get-Acl $photoPath
    $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $identity,
        "Modify",
        "ContainerInherit,ObjectInherit",
        "None",
        "Allow"
    )
    $acl.SetAccessRule($accessRule)
    Set-Acl $photoPath $acl
    Write-Success "Права на папку Photo налаштовано"
}

# =============================================
# Крок 10: Запуск сайту
# =============================================
Write-Step "Запуск сайту..."

Start-WebAppPool -Name $AppPoolName
Start-Website -Name $SiteName
Start-Sleep -Seconds 2

$appPoolState = (Get-WebAppPoolState -Name $AppPoolName).Value
$siteState = (Get-WebsiteState -Name $SiteName).Value

if ($appPoolState -eq "Started" -and $siteState -eq "Started") {
    Write-Success "Сайт успішно запущено!"
} else {
    Write-Warning-Custom "Сайт створено, але можливо не запустився"
    Write-Host "Application Pool State: $appPoolState" -ForegroundColor Gray
    Write-Host "Website State: $siteState" -ForegroundColor Gray
}

# =============================================
# Підсумок
# =============================================
Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Розгортання завершено!" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Інформація про сайт:" -ForegroundColor White
Write-Host "  Назва сайту:        $SiteName" -ForegroundColor Gray
Write-Host "  Application Pool:   $AppPoolName" -ForegroundColor Gray
Write-Host "  Фізичний шлях:      $PhysicalPath" -ForegroundColor Gray
Write-Host "  HTTP URL:           http://$HostName`:$HttpPort" -ForegroundColor Gray
if ($CertificateThumbprint -ne "") {
    Write-Host "  HTTPS URL:          https://$HostName`:$HttpsPort" -ForegroundColor Gray
}
Write-Host ""
Write-Host "Наступні кроки:" -ForegroundColor Yellow
Write-Host "  1. Налаштуйте Connection String в appsettings.json" -ForegroundColor White
Write-Host "  2. Виконайте SQL_INIT_SCRIPT.sql для додавання OpenAI API ключа" -ForegroundColor White
Write-Host "  3. Перевірте сайт у браузері" -ForegroundColor White
Write-Host "  4. Перевірте логи в: $logsPath" -ForegroundColor White
Write-Host ""
Write-Host "Для перегляду логів:" -ForegroundColor Yellow
Write-Host "  Get-ChildItem '$logsPath\*.log' | Sort-Object LastWriteTime -Descending | Select-Object -First 1 | Get-Content" -ForegroundColor Cyan
Write-Host ""
Write-Host "Успішного використання! 🚀" -ForegroundColor Green
