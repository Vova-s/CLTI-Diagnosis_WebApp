# CLTI Diagnosis - Release Package для IIS

## 📦 Що міститься в цьому пакеті

Цей пакет містить готову до розгортання версію додатку **CLTI Diagnosis** для IIS.

### Файли та папки:

- **wwwroot/** - Статичні файли (CSS, JS, Blazor WebAssembly)
- **CLTI.Diagnosis.dll** - Основний додаток
- **CLTI.Diagnosis.Client.dll** - Клієнтська частина (Blazor WebAssembly)
- **web.config** - Конфігурація IIS (з увімкненим логуванням)
- **appsettings.json** - Налаштування додатку
- **DEPLOYMENT_INSTRUCTIONS.md** - Детальна інструкція по розгортанню
- **SQL_INIT_SCRIPT.sql** - SQL скрипт для ініціалізації бази даних

---

## 🚀 Швидкий старт

### 1. Передумови

✅ Windows Server з IIS  
✅ .NET 9.0 Runtime (ASP.NET Core Hosting Bundle)  
✅ SQL Server  
✅ SSL сертифікат (для HTTPS)

### 2. Встановлення .NET 9.0 Runtime

Завантажте та встановіть **ASP.NET Core 9.0 Runtime - Windows Hosting Bundle**:
https://dotnet.microsoft.com/download/dotnet/9.0

Після встановлення перезапустіть IIS:
```powershell
iisreset
```

### 3. Копіювання файлів

Скопіюйте всі файли з цієї папки на сервер, наприклад:
```
C:\inetpub\wwwroot\CLTI-Diagnosis\
```

### 4. Налаштування бази даних

1. Відкрийте `appsettings.json`
2. Змініть Connection String:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SERVER;Database=Clti;User Id=YOUR_USER;Password=YOUR_PASSWORD;..."
  }
}
```

3. Виконайте SQL скрипт `SQL_INIT_SCRIPT.sql` в SQL Server Management Studio
4. **ВАЖЛИВО:** Замініть `YOUR_OPENAI_API_KEY_HERE` на ваш реальний OpenAI API ключ

### 5. Створення сайту в IIS

1. Відкрийте IIS Manager (`inetmgr`)
2. Створіть новий Application Pool:
   - Name: `CLTI-Diagnosis-Pool`
   - .NET CLR version: `No Managed Code`
3. Створіть новий Website:
   - Site name: `CLTI-Diagnosis`
   - Application pool: `CLTI-Diagnosis-Pool`
   - Physical path: `C:\inetpub\wwwroot\CLTI-Diagnosis`
   - Binding: HTTPS, Port 443, ваш домен

### 6. Налаштування прав

Створіть папку для логів та надайте права:
```powershell
New-Item -Path "C:\inetpub\wwwroot\CLTI-Diagnosis\logs" -ItemType Directory -Force

$identity = "IIS AppPool\CLTI-Diagnosis-Pool"
$path = "C:\inetpub\wwwroot\CLTI-Diagnosis"
$acl = Get-Acl $path
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity, "ReadAndExecute", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.SetAccessRule($accessRule)
Set-Acl $path $acl

# Права на папку logs
$logsPath = "C:\inetpub\wwwroot\CLTI-Diagnosis\logs"
$acl = Get-Acl $logsPath
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.SetAccessRule($accessRule)
Set-Acl $logsPath $acl
```

### 7. Запуск

```powershell
iisreset
```

Відкрийте браузер та перейдіть на ваш домен.

---

## 📋 Детальна інструкція

Для детальної інструкції з усіма кроками та діагностикою проблем, дивіться:
**[DEPLOYMENT_INSTRUCTIONS.md](DEPLOYMENT_INSTRUCTIONS.md)**

---

## 🔧 Діагностика

### Сайт не запускається?

1. Перевірте логи:
   ```
   C:\inetpub\wwwroot\CLTI-Diagnosis\logs\stdout_*.log
   ```

2. Перевірте Event Viewer:
   - Windows Logs → Application
   - Шукайте помилки від IIS або ASP.NET Core

3. Перевірте, чи встановлено .NET 9.0:
   ```powershell
   dotnet --list-runtimes
   ```

### CSS/JS не завантажуються?

1. Перевірте, чи існує папка `wwwroot`
2. Перевірте права доступу
3. Перевірте браузерну консоль (F12) для помилок

### "AI сервіс тимчасово недоступний"?

1. Перевірте, чи додано OpenAI API ключ в базу даних:
   ```sql
   SELECT * FROM sys_api_key WHERE Id = 1
   ```
2. Переконайтеся, що ключ не закінчився (ExpiresAt)
3. Перевірте логи додатку

---

## 📞 Підтримка

Для питань та підтримки зверніться до команди розробки.

---

## 📝 Версія

- **Версія додатку:** 1.0
- **Дата збірки:** 02.10.2025
- **.NET Version:** 9.0
- **Blazor Mode:** WebAssembly + Server

---

## ⚠️ Важливі нотатки

1. **OpenAI API ключ** - обов'язково додайте в базу даних
2. **Connection String** - змініть в `appsettings.json`
3. **SSL сертифікат** - налаштуйте для HTTPS
4. **Логування** - після успішного розгортання вимкніть детальне логування в `web.config`
5. **Права доступу** - переконайтеся, що Application Pool Identity має доступ до папок

---

## 🔐 Безпека

- Змініть стандартні паролі в Connection String
- Використовуйте HTTPS
- Обмежте доступ до папки з додатком
- Регулярно оновлюйте .NET Runtime
- Зберігайте OpenAI API ключ в безпеці

---

**Успішного розгортання! 🚀**
