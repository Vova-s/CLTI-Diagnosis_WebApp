-- =============================================
-- CLTI Diagnosis - SQL Initialization Script
-- =============================================
-- Цей скрипт додає OpenAI API ключ в базу даних
-- Виконайте його після розгортання бази даних
-- =============================================

USE [Clti]
GO

-- =============================================
-- 1. Перевірка існування таблиці sys_api_key
-- =============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'sys_api_key')
BEGIN
    PRINT 'ERROR: Таблиця sys_api_key не існує!'
    PRINT 'Спочатку виконайте міграції бази даних.'
    RETURN
END
GO

-- =============================================
-- 2. Перевірка існування запису з ID = 1
-- =============================================
IF EXISTS (SELECT 1 FROM sys_api_key WHERE Id = 1)
BEGIN
    PRINT 'Запис з ID = 1 вже існує в таблиці sys_api_key'
    PRINT 'Поточні дані:'
    SELECT 
        Id,
        LEFT(ApiKey, 10) + '...' AS ApiKey_Preview,
        Description,
        CreatedAt,
        ExpiresAt,
        StatusEnumItemId
    FROM sys_api_key 
    WHERE Id = 1
    
    PRINT ''
    PRINT 'Оновлення існуючого запису...'
    
    -- Оновлення існуючого запису
    UPDATE sys_api_key 
    SET 
        ApiKey = 'YOUR_OPENAI_API_KEY_HERE',  -- ⚠️ ЗАМІНІТЬ НА ВАШ РЕАЛЬНИЙ API КЛЮЧ
        Description = 'OpenAI API Key for AI Assistant',
        ExpiresAt = NULL,  -- Без терміну дії
        StatusEnumItemId = 1  -- Активний статус
    WHERE Id = 1
    
    PRINT 'Запис успішно оновлено!'
END
ELSE
BEGIN
    PRINT 'Запис з ID = 1 не знайдено'
    PRINT 'Створення нового запису...'
    
    -- Вставка нового запису
    INSERT INTO sys_api_key (
        Id,
        ApiKey,
        Guid,
        Description,
        CreatedAt,
        ExpiresAt,
        StatusEnumItemId
    )
    VALUES (
        1,
        'YOUR_OPENAI_API_KEY_HERE',  -- ⚠️ ЗАМІНІТЬ НА ВАШ РЕАЛЬНИЙ API КЛЮЧ
        NEWID(),
        'OpenAI API Key for AI Assistant',
        GETUTCDATE(),
        NULL,  -- Без терміну дії
        1  -- Активний статус (переконайтеся, що цей статус існує в sys_enum_item)
    )
    
    PRINT 'Запис успішно створено!'
END
GO

-- =============================================
-- 3. Перевірка результату
-- =============================================
PRINT ''
PRINT '====================================='
PRINT 'Результат виконання:'
PRINT '====================================='

SELECT 
    Id,
    CASE 
        WHEN ApiKey = 'YOUR_OPENAI_API_KEY_HERE' THEN '⚠️ НЕ НАЛАШТОВАНО - ЗАМІНІТЬ API КЛЮЧ!'
        ELSE '✓ API ключ налаштовано (' + LEFT(ApiKey, 10) + '...)'
    END AS Status,
    Description,
    CreatedAt,
    CASE 
        WHEN ExpiresAt IS NULL THEN 'Без терміну дії'
        WHEN ExpiresAt > GETUTCDATE() THEN 'Активний до ' + CONVERT(VARCHAR, ExpiresAt, 120)
        ELSE '⚠️ ЗАКІНЧИВСЯ ' + CONVERT(VARCHAR, ExpiresAt, 120)
    END AS Expiration,
    StatusEnumItemId
FROM sys_api_key 
WHERE Id = 1

PRINT ''
PRINT '====================================='
PRINT 'ВАЖЛИВО:'
PRINT '====================================='
PRINT '1. Замініть YOUR_OPENAI_API_KEY_HERE на ваш реальний OpenAI API ключ'
PRINT '2. API ключ можна отримати на https://platform.openai.com/api-keys'
PRINT '3. Переконайтеся, що ключ має доступ до моделі gpt-3.5-turbo'
PRINT '4. Після зміни ключа перезапустіть Application Pool в IIS'
PRINT '====================================='
GO

-- =============================================
-- 4. Додаткові корисні запити
-- =============================================

-- Перегляд всіх API ключів
-- SELECT * FROM sys_api_key

-- Оновлення API ключа (використовуйте цей запит для зміни ключа)
/*
UPDATE sys_api_key 
SET ApiKey = 'sk-proj-...'  -- Ваш новий ключ
WHERE Id = 1
*/

-- Перевірка терміну дії ключа
/*
SELECT 
    Id,
    Description,
    CASE 
        WHEN ExpiresAt IS NULL THEN 'Без терміну дії'
        WHEN ExpiresAt > GETUTCDATE() THEN 'Активний'
        ELSE 'Закінчився'
    END AS Status,
    ExpiresAt
FROM sys_api_key
*/

-- Видалення API ключа (використовуйте обережно!)
/*
DELETE FROM sys_api_key WHERE Id = 1
*/
