# 📦 CLTI Diagnosis - Release Build Summary

## Build Information

- **Build Date:** 02.10.2025
- **Build Configuration:** Release
- **.NET Version:** 9.0
- **Application Type:** Blazor WebAssembly + ASP.NET Core Server
- **Target Platform:** Windows Server / IIS

---

## 📁 Package Contents

### Core Application Files
- ✅ `CLTI.Diagnosis.dll` - Server application
- ✅ `CLTI.Diagnosis.Client.dll` - Blazor WebAssembly client
- ✅ `web.config` - IIS configuration (with logging enabled)
- ✅ `appsettings.json` - Application settings
- ✅ `wwwroot/` - Static files and Blazor WebAssembly assets

### Documentation
- 📄 `README.md` - Quick start guide
- 📄 `DEPLOYMENT_INSTRUCTIONS.md` - Detailed deployment instructions
- 📄 `SQL_INIT_SCRIPT.sql` - Database initialization script
- 📄 `BUILD_SUMMARY.md` - This file

### Automation Scripts
- 🔧 `Deploy-IIS.ps1` - Automated IIS deployment script

---

## ✅ Pre-Deployment Checklist

### Server Requirements
- [ ] Windows Server 2016 or newer
- [ ] IIS 10 or newer installed
- [ ] .NET 9.0 Runtime (ASP.NET Core Hosting Bundle) installed
- [ ] SQL Server accessible
- [ ] SSL certificate available (for HTTPS)

### Configuration Required
- [ ] Update Connection String in `appsettings.json`
- [ ] Execute `SQL_INIT_SCRIPT.sql` in SQL Server
- [ ] Add OpenAI API key to database (replace `YOUR_OPENAI_API_KEY_HERE`)
- [ ] Configure IIS bindings with your domain name
- [ ] Set up SSL certificate in IIS

---

## 🚀 Quick Deployment Options

### Option 1: Automated Deployment (Recommended)

Run the PowerShell script as Administrator:

```powershell
.\Deploy-IIS.ps1 -SiteName "CLTI-Diagnosis" `
                 -HostName "your-domain.com" `
                 -CertificateThumbprint "YOUR_CERT_THUMBPRINT"
```

### Option 2: Manual Deployment

Follow the step-by-step instructions in `DEPLOYMENT_INSTRUCTIONS.md`

---

## 📊 Build Statistics

### File Counts
- Total DLL files: ~70
- Static assets: Compressed (Brotli + Gzip)
- CSS bundles: Scoped and optimized
- JavaScript: Minified

### wwwroot Structure
```
wwwroot/
├── _framework/          # Blazor WebAssembly runtime (~350 files)
│   ├── blazor.webassembly.js
│   ├── dotnet.*.wasm
│   └── *.dll (compressed)
├── _content/            # Component libraries
├── Photo/               # Application images
├── app.css              # Server styles
└── CLTI.Diagnosis.Client.*.bundle.scp.css  # Client styles
```

---

## 🔧 Configuration Files

### web.config Features
- ✅ ASP.NET Core Module V2
- ✅ In-process hosting model
- ✅ Stdout logging enabled (for troubleshooting)
- ✅ Detailed error messages (disable in production)
- ✅ Security headers configured
- ✅ MIME types for Blazor WebAssembly
- ✅ Compression support (Brotli + Gzip)
- ✅ URL rewrite rules for compressed files

### appsettings.json
- Connection String (needs configuration)
- JWT settings
- Logging configuration

---

## 🔐 Security Considerations

### Included Security Features
- ✅ JWT authentication
- ✅ HTTPS redirection
- ✅ Security headers (X-Content-Type-Options, X-Frame-Options, X-XSS-Protection)
- ✅ CORS policy configured
- ✅ SQL injection protection (Entity Framework)

### Post-Deployment Security Tasks
- [ ] Change default JWT secret key
- [ ] Configure HTTPS with valid SSL certificate
- [ ] Restrict database user permissions
- [ ] Secure OpenAI API key storage
- [ ] Review and adjust CORS policy
- [ ] Disable detailed error messages in production
- [ ] Set up regular backups

---

## 📝 Important Notes

### Database
- **Required:** SQL Server database named `Clti`
- **Migration:** Ensure all EF Core migrations are applied
- **API Key:** OpenAI API key must be added to `sys_api_key` table (ID = 1)

### OpenAI Integration
- Model used: `gpt-3.5-turbo`
- Timeout: 60 seconds
- API key stored in database (table: `sys_api_key`)
- Caching: 30 minutes

### Blazor WebAssembly
- Client files are served from `wwwroot/_framework/`
- Compressed files (.br, .gz) are automatically served
- Fallback to server rendering for unsupported routes

---

## 🐛 Troubleshooting

### Common Issues

**1. Site doesn't start**
- Check logs: `C:\inetpub\wwwroot\CLTI-Diagnosis\logs\stdout_*.log`
- Verify .NET 9.0 Runtime is installed: `dotnet --list-runtimes`
- Check Event Viewer: Windows Logs → Application

**2. CSS/JS not loading**
- Verify `wwwroot` folder exists and has correct permissions
- Check browser console (F12) for 404 errors
- Ensure MIME types are configured in IIS

**3. Database connection fails**
- Verify Connection String in `appsettings.json`
- Check SQL Server is running and accessible
- Verify Application Pool Identity has database access

**4. "AI service unavailable" error**
- Check OpenAI API key in database: `SELECT * FROM sys_api_key WHERE Id = 1`
- Verify API key is valid and not expired
- Check application logs for detailed error messages

---

## 📞 Support

For issues or questions:
1. Check `DEPLOYMENT_INSTRUCTIONS.md` for detailed troubleshooting
2. Review application logs in `logs/` folder
3. Contact development team

---

## 🔄 Update Procedure

To update the application:

1. Stop the Application Pool:
   ```powershell
   Stop-WebAppPool -Name "CLTI-Diagnosis-Pool"
   ```

2. Backup current files (optional but recommended)

3. Replace all files EXCEPT:
   - `appsettings.json` (unless configuration changes are needed)
   - `web.config` (unless IIS configuration changes are needed)
   - `logs/` folder

4. Start the Application Pool:
   ```powershell
   Start-WebAppPool -Name "CLTI-Diagnosis-Pool"
   ```

---

## ✨ Features Included

### Core Features
- ✅ CLTI (Critical Limb Threatening Ischemia) diagnosis system
- ✅ WIfI classification (Wound, Ischemia, foot Infection)
- ✅ CRAB assessment (periprocedural mortality)
- ✅ 2YLE assessment (two-year survival)
- ✅ GLASS classification (anatomical arterial lesions)
- ✅ Hemodynamic indicators (ABI, TBI)
- ✅ Revascularization methods

### AI Assistant
- ✅ OpenAI GPT-3.5-turbo integration
- ✅ Medical knowledge base
- ✅ Ukrainian language support
- ✅ Conversation history

### Authentication
- ✅ JWT-based authentication
- ✅ User roles and permissions
- ✅ Secure password storage

### User Interface
- ✅ Blazor WebAssembly (client-side)
- ✅ Responsive design
- ✅ Interactive forms
- ✅ Photo upload and management

---

## 📈 Performance Optimizations

- ✅ Brotli and Gzip compression
- ✅ Static asset caching
- ✅ Lazy loading of assemblies
- ✅ Scoped CSS bundling
- ✅ Minified JavaScript
- ✅ Optimized images

---

## 📄 License

See `LICENSE.txt` for license information.

---

**Build completed successfully! Ready for deployment. 🚀**

---

*For detailed deployment instructions, see `DEPLOYMENT_INSTRUCTIONS.md`*  
*For quick start, see `README.md`*
