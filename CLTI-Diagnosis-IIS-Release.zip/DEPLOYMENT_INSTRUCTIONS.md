# CLTI Diagnosis - Інструкція по розгортанню на IIS

## Передумови

### 1. Встановлення необхідного ПЗ на сервері

- **Windows Server** (2016 або новіше)
- **IIS 10** або новіше
- **.NET 9.0 Runtime** (ASP.NET Core Runtime)
  - Завантажити з: https://dotnet.microsoft.com/download/dotnet/9.0
  - Встановити: **ASP.NET Core Runtime 9.0.x - Windows Hosting Bundle**
- **SQL Server** (для бази даних)

### 2. Налаштування IIS

#### Встановлення необхідних компонентів IIS:

```powershell
# Запустити PowerShell як адміністратор
Install-WindowsFeature -name Web-Server -IncludeManagementTools
Install-WindowsFeature -name Web-Asp-Net45
Install-WindowsFeature -name Web-ISAPI-Ext
Install-WindowsFeature -name Web-ISAPI-Filter
```

#### Перевірка встановлення ASP.NET Core Module:

```powershell
# Перевірити наявність модуля
Get-WebGlobalModule | Where-Object {$_.Name -like "*AspNetCore*"}
```

Якщо модуль не знайдено, перевстановіть **Windows Hosting Bundle**.

---

## Крок 1: Підготовка файлів

### 1.1. Копіювання файлів на сервер

Скопіюйте всі файли з папки `publish-test` на сервер в папку, наприклад:
```
C:\inetpub\wwwroot\CLTI-Diagnosis\
```

### 1.2. Структура файлів

Переконайтеся, що структура виглядає так:
```
C:\inetpub\wwwroot\CLTI-Diagnosis\
├── wwwroot/
│   ├── _framework/          # Blazor WebAssembly файли
│   ├── Photo/               # Зображення
│   ├── app.css
│   └── ...
├── CLTI.Diagnosis.dll
├── CLTI.Diagnosis.Client.dll
├── web.config
├── appsettings.json
└── ... (інші DLL файли)
```

---

## Крок 2: Налаштування бази даних

### 2.1. Створення бази даних

1. Відкрийте **SQL Server Management Studio (SSMS)**
2. Створіть нову базу даних `Clti` (або використайте існуючу)
3. Виконайте міграції (якщо є)

### 2.2. Налаштування Connection String

Відредагуйте файл `appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SERVER_NAME;Database=Clti;User Id=YOUR_USER;Password=YOUR_PASSWORD;MultipleActiveResultSets=true;TrustServerCertificate=true"
  }
}
```

**Важливо:** Замініть:
- `YOUR_SERVER_NAME` - на ім'я вашого SQL Server
- `YOUR_USER` - на ім'я користувача SQL
- `YOUR_PASSWORD` - на пароль

### 2.3. Додавання OpenAI API ключа

Виконайте SQL запит для додавання API ключа:

```sql
-- Спочатку перевірте, чи існує запис
SELECT * FROM sys_api_key WHERE Id = 1;

-- Якщо запису немає, додайте його
INSERT INTO sys_api_key (Id, ApiKey, Description, CreatedAt, StatusEnumItemId)
VALUES (1, 'YOUR_OPENAI_API_KEY', 'OpenAI API Key for AI Assistant', GETUTCDATE(), 1);

-- Якщо запис існує, оновіть його
UPDATE sys_api_key 
SET ApiKey = 'YOUR_OPENAI_API_KEY', 
    Description = 'OpenAI API Key for AI Assistant',
    ExpiresAt = NULL
WHERE Id = 1;
```

**Важливо:** Замініть `YOUR_OPENAI_API_KEY` на ваш реальний OpenAI API ключ.

---

## Крок 3: Створення Application Pool в IIS

### 3.1. Відкрийте IIS Manager

1. Натисніть `Win + R`
2. Введіть `inetmgr` і натисніть Enter

### 3.2. Створення нового Application Pool

1. В лівій панелі виберіть **Application Pools**
2. Натисніть **Add Application Pool** в правій панелі
3. Налаштування:
   - **Name:** `CLTI-Diagnosis-Pool`
   - **.NET CLR version:** `No Managed Code`
   - **Managed pipeline mode:** `Integrated`
   - Натисніть **OK**

### 3.3. Налаштування Application Pool

1. Виберіть створений pool `CLTI-Diagnosis-Pool`
2. Натисніть **Advanced Settings**
3. Налаштуйте:
   - **Identity:** `ApplicationPoolIdentity` (або створіть спеціального користувача)
   - **Start Mode:** `AlwaysRunning`
   - **Idle Time-out (minutes):** `0` (щоб не зупинявся)
   - **Regular Time Interval (minutes):** `0` (вимкнути автоматичний перезапуск)

---

## Крок 4: Створення веб-сайту в IIS

### 4.1. Створення нового сайту

1. В IIS Manager, правою кнопкою на **Sites**
2. Виберіть **Add Website**
3. Налаштування:
   - **Site name:** `CLTI-Diagnosis`
   - **Application pool:** `CLTI-Diagnosis-Pool`
   - **Physical path:** `C:\inetpub\wwwroot\CLTI-Diagnosis`
   - **Binding:**
     - **Type:** `https`
     - **IP address:** `All Unassigned`
     - **Port:** `443`
     - **Host name:** `antsdemo02.demo.dragon-cloud.org` (або ваш домен)
     - **SSL certificate:** Виберіть ваш SSL сертифікат
   - Натисніть **OK**

### 4.2. Додавання HTTP binding (опціонально)

1. Виберіть сайт `CLTI-Diagnosis`
2. Натисніть **Bindings** в правій панелі
3. Натисніть **Add**
4. Налаштування:
   - **Type:** `http`
   - **Port:** `80`
   - **Host name:** `antsdemo02.demo.dragon-cloud.org`

---

## Крок 5: Налаштування прав доступу

### 5.1. Надання прав Application Pool Identity

```powershell
# Замініть шлях на ваш
$path = "C:\inetpub\wwwroot\CLTI-Diagnosis"
$acl = Get-Acl $path

# Додати права для Application Pool Identity
$identity = "IIS AppPool\CLTI-Diagnosis-Pool"
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity, "ReadAndExecute", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.SetAccessRule($accessRule)
Set-Acl $path $acl
```

### 5.2. Створення папки для логів

```powershell
# Створити папку logs
New-Item -Path "C:\inetpub\wwwroot\CLTI-Diagnosis\logs" -ItemType Directory -Force

# Надати права на запис
$logsPath = "C:\inetpub\wwwroot\CLTI-Diagnosis\logs"
$acl = Get-Acl $logsPath
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.SetAccessRule($accessRule)
Set-Acl $logsPath $acl
```

### 5.3. Права для папки Photo (якщо потрібен запис)

```powershell
$photoPath = "C:\inetpub\wwwroot\CLTI-Diagnosis\wwwroot\Photo"
$acl = Get-Acl $photoPath
$accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity, "Modify", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.SetAccessRule($accessRule)
Set-Acl $photoPath $acl
```

---

## Крок 6: Перевірка та запуск

### 6.1. Перезапуск IIS

```powershell
iisreset
```

### 6.2. Перевірка сайту

1. Відкрийте браузер
2. Перейдіть на `https://antsdemo02.demo.dragon-cloud.org`
3. Перевірте, чи завантажується сайт

### 6.3. Перевірка логів

Якщо виникають помилки, перевірте логи:

```
C:\inetpub\wwwroot\CLTI-Diagnosis\logs\stdout_*.log
```

---

## Крок 7: Налаштування для Production

### 7.1. Вимкнути детальні помилки

Після успішного розгортання, відредагуйте `web.config`:

```xml
<!-- Закоментуйте або видаліть цей рядок -->
<!-- <httpErrors errorMode="Detailed" /> -->
```

### 7.2. Вимкнути stdout логування

В `web.config` змініть:

```xml
<aspNetCore ... stdoutLogEnabled="false" ... />
```

### 7.3. Налаштування appsettings.json

Переконайтеся, що в `appsettings.json`:

```json
{
  "Logging": {
    "LogLevel": {
      "Default": "Warning",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

---

## Діагностика проблем

### Проблема: Сайт не запускається

**Рішення:**
1. Перевірте логи в `C:\inetpub\wwwroot\CLTI-Diagnosis\logs\`
2. Перевірте Event Viewer (Windows Logs → Application)
3. Переконайтеся, що .NET 9.0 Runtime встановлено:
   ```powershell
   dotnet --list-runtimes
   ```

### Проблема: CSS/JS файли не завантажуються

**Рішення:**
1. Перевірте, чи існує папка `wwwroot`
2. Перевірте права доступу до папки
3. Перевірте, чи правильно налаштовані MIME types в IIS

### Проблема: "Connection refused" до бази даних

**Рішення:**
1. Перевірте Connection String в `appsettings.json`
2. Переконайтеся, що SQL Server запущено
3. Перевірте, чи Application Pool Identity має доступ до бази даних

### Проблема: "AI сервіс тимчасово недоступний"

**Рішення:**
1. Перевірте, чи додано OpenAI API ключ в таблицю `sys_api_key`
2. Перевірте, чи ключ не закінчився (поле `ExpiresAt`)
3. Перевірте логи для деталей помилки

---

## Оновлення додатку

### Для оновлення:

1. Зупиніть Application Pool:
   ```powershell
   Stop-WebAppPool -Name "CLTI-Diagnosis-Pool"
   ```

2. Замініть файли (крім `appsettings.json` та `web.config`)

3. Запустіть Application Pool:
   ```powershell
   Start-WebAppPool -Name "CLTI-Diagnosis-Pool"
   ```

---

## Контакти та підтримка

Для питань та підтримки зверніться до команди розробки.

**Версія документа:** 1.0  
**Дата:** 02.10.2025
